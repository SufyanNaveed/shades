<?php

namespace Salla\ZATCA\Test;

class TestCase extends \PHPUnit\Framework\TestCase
{
}
