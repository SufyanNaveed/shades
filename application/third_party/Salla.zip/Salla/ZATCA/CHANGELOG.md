# Changelog

All notable changes to `salla/zatca` will be documented in this file

## 1.0.2 - 2021-10-14

- Support Arabic

## 1.0.0 - 2021-10-11

- initial release
